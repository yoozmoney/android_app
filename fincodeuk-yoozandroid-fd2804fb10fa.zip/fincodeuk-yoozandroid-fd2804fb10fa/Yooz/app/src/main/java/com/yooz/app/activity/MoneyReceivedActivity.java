package com.yooz.app.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MoneyReceivedActivity extends AppCompatActivity {
    @BindView(R.id.layBack)
    LinearLayout layBack;
    @BindView(R.id.laySupport)
    LinearLayout laySupport;
    @BindView(R.id.txtTitleName)
    TextView txtTitleName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money_received);
        ButterKnife.bind(this);
        txtTitleName.setText("Money received");
        initilization();
    }

    private void initilization() {
        laySupport.setVisibility(View.INVISIBLE);
        layBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
