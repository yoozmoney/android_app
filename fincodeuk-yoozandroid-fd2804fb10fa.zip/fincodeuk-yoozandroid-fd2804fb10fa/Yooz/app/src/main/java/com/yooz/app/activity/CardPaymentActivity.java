package com.yooz.app.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CardPaymentActivity extends AppCompatActivity {
    @BindView(R.id.txtHeaderText1)
    TextView txtHeaderText1;
    @BindView(R.id.txtUseDifferentCard)TextView txtUseDifferentCard;
    @BindView(R.id.layBack)
    LinearLayout layBack;
    @BindView(R.id.txtTitleName) TextView txtTitleName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_payment);
        ButterKnife.bind(this);
        txtTitleName.setText("Card payment");
        txtHeaderText1.setText("Continue");
        txtHeaderText1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent intent=new Intent(EnterCardDetailActivity.this,EnterCardDetailActivity.class);
//                startActivity(intent);
            }
        });
        layBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        txtUseDifferentCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(CardPaymentActivity.this,EnterCardDetailActivity.class);
                startActivity(intent);
            }
        });
    }
}
