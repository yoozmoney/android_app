package com.yooz.app.activity;

import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

/**
 * Created by daksha2 on 23/11/16.
 */

public class BaseActivity extends AppCompatActivity {

    public void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT)
                .show();
    }
}
