package com.yooz.app.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class FindAddressActivity extends AppCompatActivity {
    @BindView(R.id.txtTitleName)
    TextView txtTitleName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_address);
        ButterKnife.bind(this);
        txtTitleName.setText("Find address");
    }
}
