package com.yooz.app.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SendMoneyActivity extends AppCompatActivity {
    @BindView(R.id.txtHeaderText1) TextView txtHeaderText1;
    @BindView(R.id.layBack) LinearLayout layBack;
    @BindView(R.id.txtTitleName) TextView txtTitleName;
    @BindView(R.id.imgI)ImageView imgI;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_money);
        ButterKnife.bind(this);
        txtTitleName.setText("Send money");
        txtHeaderText1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SendMoneyActivity.this,SelectPaymentMethodActivity.class);
                startActivity(intent);
            }
        });
        layBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        imgI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SendMoneyActivity.this,OurRealExchangeRateActivity.class);
                startActivity(intent);
            }
        });
    }
}
