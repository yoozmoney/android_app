package com.yooz.app.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.yooz.app.R;

public class CreateSendingAndRequestMoneyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_sending_and_request_money);
    }
}
