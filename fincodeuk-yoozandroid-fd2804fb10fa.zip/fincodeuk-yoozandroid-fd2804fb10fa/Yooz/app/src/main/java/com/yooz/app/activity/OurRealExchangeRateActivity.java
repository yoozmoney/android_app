package com.yooz.app.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;

public class OurRealExchangeRateActivity extends AppCompatActivity {
    @BindView(R.id.txtHeaderText1)
    TextView txtHeaderText1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_our_real_exchange_rate);
    }
}
