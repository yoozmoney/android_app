package com.yooz.app.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.yooz.app.R.drawable.green_rounded_border;

public class SelectPaymentMethodActivity extends BaseActivity {
    @BindView(R.id.txtHeaderText1)
    TextView txtHeaderText1;
    @BindView(R.id.layBack)
    LinearLayout layBack;
    @BindView(R.id.txtTitleName)
    TextView txtTitleName;
    @BindView(R.id.layBankTransfer)
    LinearLayout layBankTransfer;
    @BindView(R.id.imgBankTransfer)
    ImageView imgBankTransfer;
    @BindView(R.id.imgBTGreenTick)
    ImageView imgBTGreenTick;
    @BindView(R.id.txtBankTransfer)
    TextView txtBankTransfer;
    @BindView(R.id.layCardPayment)
    LinearLayout layCardPayment;
    @BindView(R.id.imgCardPayment)
    ImageView imgCardPayment;
    @BindView(R.id.imgCPGreenTick)
    ImageView imgCPGreenTick;
    @BindView(R.id.txtCardPayment)
    TextView txtCardPayment;
    String strPayment="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_payment_method);
        ButterKnife.bind(this);
        initilization();

    }

    private void initilization() {
        txtTitleName.setText("Select payment method");
        txtHeaderText1.setText("Confirm");
        txtHeaderText1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (strPayment.equalsIgnoreCase("BankTransfer")) {
                    Intent intent = new Intent(SelectPaymentMethodActivity.this, BankTransferActivity.class);
                    startActivity(intent);

                } else if (strPayment.equalsIgnoreCase("CardPayment")) {
                    Intent intent = new Intent(SelectPaymentMethodActivity.this, CardPaymentActivity.class);
                    startActivity(intent);
                } else if(strPayment.equals("")) {
                    showToast("please select payment");
                }

            }
        });
        layBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        layBankTransfer.setOnClickListener(paymentOptionClickListener);
        layCardPayment.setOnClickListener(paymentOptionClickListener);
        layBankTransfer.setTag(0);
        layCardPayment.setTag(1);
//        layBankTransfer.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });

    }

    private View.OnClickListener paymentOptionClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int tag = (int) view.getTag();
            paymentOption(tag);
        }
    };
    int val;

    private void paymentOption(int tag) {
        val = tag;
        switch (tag) {
            case 0:
                layBankTransfer.setBackgroundResource(R.drawable.green_rounded_border);
                imgBankTransfer.setImageResource(R.drawable.bank_transfer_green);
                txtBankTransfer.setTextColor(getResources().getColor(R.color.green, null));
                imgBTGreenTick.setVisibility(View.VISIBLE);

                layCardPayment.setBackgroundResource(R.drawable.rounded_border);
                imgCardPayment.setImageResource(R.drawable.card_payment);
                txtCardPayment.setTextColor(getResources().getColor(R.color.black, null));
                imgCPGreenTick.setVisibility(View.GONE);
                strPayment = "BankTransfer";
                break;
            case 1:
                layBankTransfer.setBackgroundResource(R.drawable.rounded_border);
                imgBankTransfer.setImageResource(R.drawable.bank_transfer_payment);
                txtBankTransfer.setTextColor(getResources().getColor(R.color.black, null));
                imgBTGreenTick.setVisibility(View.GONE);

                layCardPayment.setBackgroundResource(R.drawable.green_rounded_border);
                imgCardPayment.setImageResource(R.drawable.card_payment_green);
                txtCardPayment.setTextColor(getResources().getColor(R.color.green, null));
                imgCPGreenTick.setVisibility(View.VISIBLE);
                strPayment = "CardPayment";
                break;
        }
    }

}
