package com.yooz.app.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BankDetailsActivity extends AppCompatActivity {
    @BindView(R.id.txtHeaderText1)
    TextView txtHeaderText1;
    @BindView(R.id.txtTitle) TextView txtTitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bank_details);
        ButterKnife.bind(this);
        txtTitle.setText("Tell us about yourself");
        txtHeaderText1.setText("Continue");
    }
}
