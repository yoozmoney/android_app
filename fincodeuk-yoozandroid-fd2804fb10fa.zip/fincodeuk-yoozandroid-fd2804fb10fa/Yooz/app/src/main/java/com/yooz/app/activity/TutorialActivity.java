package com.yooz.app.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class TutorialActivity extends BaseActivity {
    @BindView(R.id.layTutorialOne) LinearLayout layTutorialOne;
    @BindView(R.id.layTutorialTwo) LinearLayout layTutorialTwo;
    @BindView(R.id.layTutorialThree) LinearLayout layTutorialThree;
    @BindView(R.id.layTutorialFour) LinearLayout layTutorialFour;
    @BindView(R.id.txtHeaderText2) TextView txtHeaderText2;
    @BindView(R.id.txtHeaderText1) TextView txtHeaderText1;
    @BindView(R.id.txtHeaderText3) TextView txtHeaderText3;
    @BindView(R.id.txtHeaderText4) TextView txtHeaderText4;
@OnClick(R.id.txtHeaderText1) void submit() {
    layTutorialOne.setVisibility(View.GONE);
    layTutorialTwo.setVisibility(View.VISIBLE);
    txtHeaderText1.setVisibility(View.GONE);
    txtHeaderText2.setVisibility(View.VISIBLE);
}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);
        ButterKnife.bind(this);
        txtHeaderText2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layTutorialThree.setVisibility(View.VISIBLE);
                layTutorialOne.setVisibility(View.GONE);
                layTutorialTwo.setVisibility(View.GONE);
                txtHeaderText1.setVisibility(View.GONE);
                txtHeaderText2.setVisibility(View.GONE);
                txtHeaderText3.setVisibility(View.VISIBLE);
            }
        });
        txtHeaderText3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layTutorialThree.setVisibility(View.GONE);
                layTutorialOne.setVisibility(View.GONE);
                layTutorialTwo.setVisibility(View.GONE);
                txtHeaderText1.setVisibility(View.GONE);
                txtHeaderText2.setVisibility(View.GONE);
                txtHeaderText3.setVisibility(View.GONE);
                layTutorialFour.setVisibility(View.VISIBLE);
                txtHeaderText4.setVisibility(View.VISIBLE);
                txtHeaderText4.setText("Let’s go");
            }
        });
        txtHeaderText4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(TutorialActivity.this,ChooseReceipentActivity.class);
                startActivity(intent);
            }
        });
    }
}
