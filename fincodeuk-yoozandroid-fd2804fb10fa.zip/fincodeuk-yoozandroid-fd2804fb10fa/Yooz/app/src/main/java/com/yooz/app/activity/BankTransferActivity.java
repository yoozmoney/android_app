package com.yooz.app.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.yooz.app.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BankTransferActivity extends AppCompatActivity {
    @BindView(R.id.txtHeaderText1)
    TextView txtHeaderText1;
    @BindView(R.id.txtTitleName) TextView txtTitleName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bank_transfer);
        ButterKnife.bind(this);
        txtHeaderText1.setText("I have made the transfer");
        txtTitleName.setText("Bank transfer");
    }
}
